import 'package:flutter/material.dart';

class ThreeDCourseScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final primaryColor = Colors.blue;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white, 
        title: Text(
          '3D Design Basic',
          style: TextStyle(color: Colors.black), 
        ),
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 1,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.network(
                'lib/img/bg.png',
                height: 150,
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Icon(Icons.star, color: Colors.amber, size: 20),
                Icon(Icons.star, color: Colors.amber, size: 20),
                Icon(Icons.star, color: Colors.amber, size: 20),
                Icon(Icons.star, color: Colors.amber, size: 20),
                Icon(Icons.star_half, color: Colors.amber, size: 20),
                SizedBox(width: 8),
                Text('4.5/5'),
              ],
            ),
            SizedBox(height: 16),
            Text(
              'In this course you will learn how to build a space to a 3-dimensional product. There are 24 premium learning videos for you.',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),

            Text(
              '24 Lessons (20 hours)',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            SizedBox(height: 8),

            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {},
                child: Text('See all', style: TextStyle(color: primaryColor)),
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Lessons',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryColor),
            ),
            SizedBox(height: 8),
            _buildLessonItem('Introduction to 3D', primaryColor),
            _buildLessonItem('2D HTMLs', primaryColor),

            Spacer(),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                ),
                onPressed: () {},
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Enroll - \$24.99',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white, 
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLessonItem(String title, Color color) {
    return Card(
      margin: EdgeInsets.only(bottom: 8),
      elevation: 3,
      child: ListTile(
        leading: Image.network(
          'lib/img/bg.png',
          width: 50,
          height: 50,
        ),
        title: Text(title),
        trailing: Icon(Icons.check_circle_outline, color: color),
      ),
    );
  }
}
