import 'package:flutter/material.dart';

class MeditateNowLoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('lib/img/bg.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            color: Colors.black.withOpacity(0.4),
          ),
          Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              children: [
                SizedBox(height: 60),
                Align(
                  alignment: Alignment.centerLeft
                ),
                Spacer(),
                Text(
                  'medinow',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Meditate With Us!',
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                SizedBox(height: 40),
                _buildSocialButton(
                  icon: Icons.apple,
                  text: 'Sign in with Apple',
                  color: Colors.white,
                  textColor: Colors.black,
                ),
                SizedBox(height: 16),
                _buildSocialButton(
                  icon: Icons.email,
                  text: 'Continue with Email or Phone',
                  color: Colors.blue,
                  textColor: Colors.white,
                ),
                SizedBox(height: 16),
                _buildSocialButton(
                  icon: Icons.g_mobiledata,
                  text: 'Continue With Google',
                  color: Colors.white,
                  textColor: Colors.black,
                ),
                SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialButton({
    required IconData icon,
    required String text,
    required Color color,
    required Color textColor,
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        icon: Icon(icon),
        label: Text(text),
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: color,  // Заменено с primary на backgroundColor
          foregroundColor: textColor,  // Заменено с onPrimary на foregroundColor
          padding: EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}