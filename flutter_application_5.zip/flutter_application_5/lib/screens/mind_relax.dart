import 'package:flutter/material.dart';

class MeditationPage extends StatelessWidget {
  const MeditationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Mindful Sessions',
          style: TextStyle(color: Colors.black), 
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.white, 
        iconTheme: const IconThemeData(color: Colors.black), 
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(
                  'lib/img/ioga.png',
                  height: 200,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Mind Deep Relax',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Join the Community as we prepare over 33 days to relax and feel joy with the mind and happiness session across the World.',
              style: TextStyle(
                fontSize: 16,
                height: 1.5,
                color: Colors.black.withOpacity(0.8), 
              ),
            ),
            const SizedBox(height: 24),
            Divider(color: Colors.grey[300]), 
            const SizedBox(height: 24),
            Center(
              child: ElevatedButton(
                onPressed: () {
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[700],
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  'Play Next Session',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            _buildSessionItem(
              title: 'Sweet Memories',
              date: 'December 29 Pre-Launch',
            ),
            _buildSessionItem(
              title: 'A Day Dream',
              date: 'December 29 Pre-Launch',
            ),
            _buildSessionItem(
              title: 'Mind Explore',
              date: 'December 29 Pre-Launch',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionItem({required String title, required String date}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey[100], 
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            IconButton(
              icon: Icon(Icons.play_circle_fill, color: Colors.blue[700], size: 36),
              onPressed: () {
              },
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    date,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.black.withOpacity(0.6), 
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: Icon(Icons.more_horiz, color: Colors.grey[600], size: 28),
              onPressed: () {
              },
            ),
          ],
        ),
      ),
    );
  }
}