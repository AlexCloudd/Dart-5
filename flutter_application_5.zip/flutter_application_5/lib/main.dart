import 'package:flutter/material.dart';
import 'screens/popular_menu.dart';
import 'screens/organizer_profile.dart';
import 'screens/course_screen.dart';
import 'screens/mind_relax.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Food & Meditation App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomeScreen(), 
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Главное меню'),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildNavigationButton(
                context: context,
                text: 'Популярное меню',
                screen: PopularMenuScreen(),
              ),
              SizedBox(height: 16),
              _buildNavigationButton(
                context: context,
                text: 'Профиль организатора',
                screen: OrganizerProfileScreen(),
              ),
              SizedBox(height: 16),
              _buildNavigationButton(
                context: context,
                text: 'Курс 3D дизайна',
                screen: ThreeDCourseScreen(),
              ),
              SizedBox(height: 16),
              _buildNavigationButton(
                context: context,
                text: 'Медитация',
                screen: MeditationPage(),
              ),
              SizedBox(height: 16),
              _buildNavigationButton(
                context: context,
                text: 'Экран входа',
                screen: MeditateNowLoginScreen(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavigationButton({
    required BuildContext context,
    required String text,
    required Widget screen,
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          padding: EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => screen),
          );
        },
        child: Text(
          text,
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}